import React from 'react';
import ReportForm from '../components/report/ReportForm';

const ReportPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 mt-16">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">Report Unsafe Area</h1>
        <div className="bg-gray-50 p-4 rounded-md mb-6">
          <p className="text-gray-700">
            Help make our community safer by reporting unsafe areas or incidents. Your reports contribute to safer routes for everyone.
          </p>
        </div>
        
        <ReportForm />
      </div>
    </div>
  );
};

export default ReportPage;