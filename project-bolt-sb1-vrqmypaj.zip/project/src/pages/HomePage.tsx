import React from 'react';
import { Shield, MapPin, AlertTriangle, User, ChevronRight } from 'lucide-react';
import Button from '../components/common/Button';
import { Link } from '../components/router/Link';

const HomePage: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-purple-900 to-purple-700 text-white">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Navigate Your World Safely with AI-Powered Route Guidance</h1>
            <p className="text-xl mb-8">
              SafeWalk AI uses real-time data to predict the safety level of routes, helping women travel confidently in urban areas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                variant="secondary" 
                size="lg"
                icon={<MapPin className="h-5 w-5" />}
              >
                <Link to="/map" className="text-white">
                  Try the Safety Map
                </Link>
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                icon={<User className="h-5 w-5" />}
              >
                <Link to="/signup" className="text-white">
                  Create an Account
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">How SafeWalk AI Works</h2>
            <p className="text-xl text-gray-600 mt-4">Advanced technology for your personal safety</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center transform transition-transform hover:scale-105">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-purple-700" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Real-time Safety Mapping</h3>
              <p className="text-gray-600">
                Our AI analyzes crime data, lighting conditions, and crowd information to assign safety scores to streets and routes.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center transform transition-transform hover:scale-105">
              <div className="bg-teal-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="h-8 w-8 text-teal-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Community Reporting</h3>
              <p className="text-gray-600">
                Users can report unsafe areas, contributing to our crowdsourced safety database that improves route recommendations.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md text-center transform transition-transform hover:scale-105">
              <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Emergency SOS</h3>
              <p className="text-gray-600">
                Quickly alert emergency contacts with your location using voice commands if you feel unsafe or threatened.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">Safety at Your Fingertips</h2>
            <p className="text-xl text-gray-600 mt-4">Simple steps to navigate safely</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="relative">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-purple-800 font-bold text-xl">1</div>
              <h3 className="text-lg font-semibold mb-2">Enter Your Destination</h3>
              <p className="text-gray-600 mb-6">
                Input where you want to go, and SafeWalk AI will generate route options.
              </p>
              <ChevronRight className="hidden md:block absolute top-8 -right-4 h-6 w-6 text-gray-400" />
            </div>

            <div className="relative">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-purple-800 font-bold text-xl">2</div>
              <h3 className="text-lg font-semibold mb-2">Review Safety Scores</h3>
              <p className="text-gray-600 mb-6">
                Compare routes based on their color-coded safety ratings and additional information.
              </p>
              <ChevronRight className="hidden md:block absolute top-8 -right-4 h-6 w-6 text-gray-400" />
            </div>

            <div className="relative">
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-purple-800 font-bold text-xl">3</div>
              <h3 className="text-lg font-semibold mb-2">Choose Your Route</h3>
              <p className="text-gray-600 mb-6">
                Select the safest route that meets your needs and time constraints.
              </p>
              <ChevronRight className="hidden md:block absolute top-8 -right-4 h-6 w-6 text-gray-400" />
            </div>

            <div>
              <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-purple-800 font-bold text-xl">4</div>
              <h3 className="text-lg font-semibold mb-2">Travel with Confidence</h3>
              <p className="text-gray-600 mb-6">
                Navigate safely with real-time updates and emergency features if needed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800">User Experiences</h2>
            <p className="text-xl text-gray-600 mt-4">What our community says about SafeWalk AI</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-purple-200 flex items-center justify-center text-purple-800 font-bold text-xl">P</div>
                <div className="ml-4">
                  <h4 className="font-semibold">Priya S.</h4>
                  <p className="text-gray-500 text-sm">Delhi, India</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "SafeWalk AI has completely changed how I navigate the city at night. I feel empowered knowing which routes are safer."
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-teal-200 flex items-center justify-center text-teal-800 font-bold text-xl">J</div>
                <div className="ml-4">
                  <h4 className="font-semibold">Jessica T.</h4>
                  <p className="text-gray-500 text-sm">New York, USA</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "The emergency SOS feature gave me peace of mind when I had to walk home late from work. Thankfully I never had to use it!"
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-purple-200 flex items-center justify-center text-purple-800 font-bold text-xl">M</div>
                <div className="ml-4">
                  <h4 className="font-semibold">Maria G.</h4>
                  <p className="text-gray-500 text-sm">São Paulo, Brazil</p>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I reported a poorly lit street near my university, and within weeks, others had confirmed it and the city installed new lights!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-purple-700 to-purple-900 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Navigate Safely?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Join thousands of women who use SafeWalk AI to travel with confidence every day.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              variant="secondary" 
              size="lg"
            >
              <Link to="/signup" className="text-white">
                Create Free Account
              </Link>
            </Button>
            <Button 
              variant="outline" 
              size="lg"
            >
              <Link to="/map" className="text-white">
                Try Demo
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;