import React from 'react';
import { Shield, Activity, AlertCircle, Target, Award, Users } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8 mt-16">
      <div className="max-w-4xl mx-auto">
        <section className="mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-6">About SafeWalk AI</h1>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-lg leading-relaxed text-gray-700 mb-6">
              SafeWalk AI was born from a simple yet powerful vision: to give women the confidence to navigate urban spaces without fear. We believe technology can be harnessed to create safer communities and empower individuals.
            </p>
            <p className="text-lg leading-relaxed text-gray-700">
              Our AI-driven platform combines real-time data with crowdsourced information to provide accurate safety predictions for routes in metropolitan areas. By analyzing factors like crime statistics, lighting conditions, crowd density, and user reports, we create detailed safety maps that help our users make informed decisions about their travel routes.
            </p>
          </div>
        </section>
        
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Mission</h2>
          <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
            <div className="mr-6 hidden md:block">
              <Target className="h-16 w-16 text-purple-700" />
            </div>
            <div>
              <p className="text-lg leading-relaxed text-gray-700">
                Our mission is to reduce gender-based violence and harassment in public spaces by leveraging technology and community engagement. We aim to create a world where everyone, regardless of gender, can move freely and confidently through urban environments.
              </p>
            </div>
          </div>
        </section>
        
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Shield className="h-8 w-8 text-purple-700 mr-3" />
                <h3 className="text-xl font-semibold">Safety First</h3>
              </div>
              <p className="text-gray-700">
                We prioritize user safety in every feature we develop and every decision we make.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Activity className="h-8 w-8 text-purple-700 mr-3" />
                <h3 className="text-xl font-semibold">Data-Driven</h3>
              </div>
              <p className="text-gray-700">
                We believe in the power of data to transform communities and create positive change.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-purple-700 mr-3" />
                <h3 className="text-xl font-semibold">Community Focused</h3>
              </div>
              <p className="text-gray-700">
                We leverage collective intelligence and foster community participation to create safer environments.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <AlertCircle className="h-8 w-8 text-purple-700 mr-3" />
                <h3 className="text-xl font-semibold">Transparency</h3>
              </div>
              <p className="text-gray-700">
                We are committed to being open about how our technology works and how we use data.
              </p>
            </div>
          </div>
        </section>
        
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Our Team</h2>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <p className="text-lg leading-relaxed text-gray-700 mb-6">
              SafeWalk AI was founded by a diverse group of technologists, safety advocates, and urban planners passionate about using technology for social good. Our team combines expertise in artificial intelligence, data science, user experience design, and community engagement.
            </p>
            <p className="text-lg leading-relaxed text-gray-700">
              We are united by our commitment to creating safer cities and empowering women through technology. Our team works closely with community organizations, law enforcement agencies, and urban planning departments to ensure our platform addresses real-world safety concerns.
            </p>
          </div>
        </section>
        
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Impact</h2>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-6">
              <Award className="h-10 w-10 text-purple-700 mr-4" />
              <h3 className="text-2xl font-semibold">Making a Difference</h3>
            </div>
            <p className="text-lg leading-relaxed text-gray-700 mb-4">
              Since launching SafeWalk AI, we've helped thousands of women navigate cities more confidently. Our community-driven approach has led to tangible improvements in urban safety:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
              <li>Over 5,000 unsafe areas identified and reported to local authorities</li>
              <li>Partnerships with 15+ cities to improve lighting and infrastructure in problem areas</li>
              <li>Reduction in incidents reported along frequently traveled routes</li>
              <li>Creation of a real-time safety database that helps predict and prevent potential risks</li>
            </ul>
            <p className="text-lg leading-relaxed text-gray-700">
              We believe that technology alone cannot solve safety issues, but when combined with community engagement and policy changes, it can be a powerful catalyst for creating safer urban environments for everyone.
            </p>
          </div>
        </section>
      </div>
    </div>
  );
};

export default AboutPage;