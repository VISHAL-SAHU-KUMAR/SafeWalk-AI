import React, { useState } from 'react';
import { Menu, X, Shield, MapPin, AlertTriangle, User, Home, Phone, Info } from 'lucide-react';
import { Link } from '../router/Link';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-gradient-to-r from-purple-900 to-purple-700 text-white shadow-md fixed w-full z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link to="/" className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-teal-300" />
            <span className="text-xl font-bold">SafeWalk AI</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">
            <Link to="/" className="flex items-center hover:text-teal-300 transition-colors">
              <Home className="h-4 w-4 mr-1" /> Home
            </Link>
            <Link to="/map" className="flex items-center hover:text-teal-300 transition-colors">
              <MapPin className="h-4 w-4 mr-1" /> Safety Map
            </Link>
            <Link to="/report" className="flex items-center hover:text-teal-300 transition-colors">
              <AlertTriangle className="h-4 w-4 mr-1" /> Report
            </Link>
            <Link to="/about" className="flex items-center hover:text-teal-300 transition-colors">
              <Info className="h-4 w-4 mr-1" /> About
            </Link>
            <Link to="/contact" className="flex items-center hover:text-teal-300 transition-colors">
              <Phone className="h-4 w-4 mr-1" /> Contact
            </Link>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <Link 
              to="/login" 
              className="px-4 py-2 rounded hover:bg-purple-800 transition-colors"
            >
              Login
            </Link>
            <Link 
              to="/signup" 
              className="px-4 py-2 bg-teal-500 hover:bg-teal-600 rounded transition-colors"
            >
              Sign Up
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMenu}
              className="p-2 focus:outline-none focus:ring-2 focus:ring-teal-300 rounded"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 bg-purple-800 rounded-b-lg">
            <div className="flex flex-col space-y-3 px-4 py-2">
              <Link to="/" className="flex items-center py-2 hover:bg-purple-700 px-3 rounded">
                <Home className="h-5 w-5 mr-2" /> Home
              </Link>
              <Link to="/map" className="flex items-center py-2 hover:bg-purple-700 px-3 rounded">
                <MapPin className="h-5 w-5 mr-2" /> Safety Map
              </Link>
              <Link to="/report" className="flex items-center py-2 hover:bg-purple-700 px-3 rounded">
                <AlertTriangle className="h-5 w-5 mr-2" /> Report
              </Link>
              <Link to="/about" className="flex items-center py-2 hover:bg-purple-700 px-3 rounded">
                <Info className="h-5 w-5 mr-2" /> About
              </Link>
              <Link to="/contact" className="flex items-center py-2 hover:bg-purple-700 px-3 rounded">
                <Phone className="h-5 w-5 mr-2" /> Contact
              </Link>
              <div className="pt-2 border-t border-purple-600 flex flex-col space-y-2">
                <Link 
                  to="/login" 
                  className="w-full py-2 text-center rounded hover:bg-purple-700 transition-colors"
                >
                  Login
                </Link>
                <Link 
                  to="/signup" 
                  className="w-full py-2 text-center bg-teal-500 hover:bg-teal-600 rounded transition-colors"
                >
                  Sign Up
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;