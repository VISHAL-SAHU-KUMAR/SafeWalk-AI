import React, { useState, useEffect } from 'react';

interface Route {
  path: string;
  element: React.ReactNode;
}

interface RouterProps {
  routes: Route[];
}

const Router: React.FC<RouterProps> = ({ routes }) => {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  useEffect(() => {
    const onLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };

    window.addEventListener('popstate', onLocationChange);

    return () => {
      window.removeEventListener('popstate', onLocationChange);
    };
  }, []);

  const getCurrentRoute = () => {
    // First check for exact path matches
    const exactRoute = routes.find(route => route.path === currentPath);
    if (exactRoute) return exactRoute.element;

    // Handle root path
    if (currentPath === '/') {
      const homeRoute = routes.find(route => route.path === '/');
      if (homeRoute) return homeRoute.element;
    }

    // If no matching route, show 404 or default content
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Page Not Found</h1>
        <p className="text-gray-600 mb-8">The page you're looking for doesn't exist or has been moved.</p>
      </div>
    );
  };

  return <>{getCurrentRoute()}</>;
};

export default Router;