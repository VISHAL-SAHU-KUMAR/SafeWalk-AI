import React, { useState } from 'react';
import { Map, MapPin, Navigation, AlertTriangle } from 'lucide-react';
import Button from '../common/Button';

// Mock data for demonstration
const mockSafetyData = [
  { id: 1, lat: 40.712776, lng: -74.005974, safetyScore: 85, name: "Broadway & Houston" },
  { id: 2, lat: 40.718217, lng: -73.998284, safetyScore: 45, name: "NoHo District" },
  { id: 3, lat: 40.730610, lng: -73.935242, safetyScore: 65, name: "Williamsburg Bridge" },
  { id: 4, lat: 40.748817, lng: -73.985428, safetyScore: 90, name: "Bryant Park" },
  { id: 5, lat: 40.758896, lng: -73.985130, safetyScore: 30, name: "Times Square" },
];

const SafetyMap: React.FC = () => {
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [destination, setDestination] = useState('');

  const getSafetyColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    if (score >= 40) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would trigger a route search using the destination
    setSelectedRoute('Sample Route');
  };

  const handleEmergencySOS = () => {
    alert('Emergency SOS triggered! In a real application, this would contact emergency services and trusted contacts.');
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden h-full">
      <div className="p-4 bg-purple-700 text-white">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold flex items-center">
            <Map className="mr-2 h-5 w-5" /> Safety Map
          </h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setViewMode('map')}
              className={`p-2 rounded ${viewMode === 'map' ? 'bg-purple-900' : 'bg-purple-800 hover:bg-purple-900'}`}
            >
              <Map className="h-4 w-4" />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={`p-2 rounded ${viewMode === 'list' ? 'bg-purple-900' : 'bg-purple-800 hover:bg-purple-900'}`}
            >
              <div className="h-4 w-4 flex flex-col justify-center items-center">
                <div className="w-3 h-0.5 bg-white mb-0.5"></div>
                <div className="w-3 h-0.5 bg-white mb-0.5"></div>
                <div className="w-3 h-0.5 bg-white"></div>
              </div>
            </button>
          </div>
        </div>
        
        <form onSubmit={handleSearch} className="flex gap-2">
          <input
            type="text"
            placeholder="Enter destination"
            className="flex-1 px-3 py-2 bg-purple-800 text-white placeholder-purple-300 rounded focus:outline-none focus:ring-2 focus:ring-teal-400"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
          />
          <Button 
            type="submit" 
            variant="secondary" 
            size="sm"
            icon={<Navigation className="h-4 w-4" />}
          >
            Go
          </Button>
        </form>
      </div>

      <div className="p-4 relative">
        {viewMode === 'map' ? (
          <div className="bg-gray-200 h-80 rounded flex items-center justify-center">
            {/* This would be replaced with an actual map component in a real implementation */}
            <div className="text-center text-gray-500">
              <Map className="h-16 w-16 mx-auto mb-2 text-gray-400" />
              <p>Interactive map would display here with color-coded safety routes</p>
              <p className="text-sm">Routes colored by safety: Green (Safe), Yellow (Use Caution), Orange (Be Alert), Red (Avoid)</p>
            </div>

            {/* Safety legend */}
            <div className="absolute bottom-8 right-8 bg-white p-2 rounded shadow-md text-xs">
              <div className="font-semibold mb-1">Safety Index</div>
              <div className="flex items-center mb-1">
                <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                <span>80-100: Very Safe</span>
              </div>
              <div className="flex items-center mb-1">
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
                <span>60-79: Generally Safe</span>
              </div>
              <div className="flex items-center mb-1">
                <div className="w-3 h-3 rounded-full bg-orange-500 mr-1"></div>
                <span>40-59: Use Caution</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                <span>0-39: Exercise Extreme Caution</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <h3 className="font-medium text-gray-700">Nearby Locations Safety Ratings</h3>
            {mockSafetyData.map(location => (
              <div key={location.id} className="bg-gray-50 p-3 rounded-md shadow-sm flex items-center">
                <div className={`w-12 h-12 rounded-full ${getSafetyColor(location.safetyScore)} text-white flex items-center justify-center font-bold`}>
                  {location.safetyScore}
                </div>
                <div className="ml-3 flex-grow">
                  <h4 className="font-medium">{location.name}</h4>
                  <p className="text-xs text-gray-500">
                    {location.safetyScore >= 80 ? 'Very Safe' : 
                     location.safetyScore >= 60 ? 'Generally Safe' :
                     location.safetyScore >= 40 ? 'Use Caution' : 'Exercise Extreme Caution'}
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  icon={<Navigation className="h-4 w-4" />}
                >
                  Route
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-red-600 p-3 flex justify-center">
        <Button 
          variant="danger" 
          size="lg"
          icon={<AlertTriangle className="h-5 w-5" />}
          onClick={handleEmergencySOS}
          className="shadow-lg animate-pulse"
        >
          Emergency SOS
        </Button>
      </div>
    </div>
  );
};

export default SafetyMap;