import React, { useState } from 'react';
import { AlertTriangle, Camera, MapPin, Send } from 'lucide-react';
import Button from '../common/Button';

interface ReportFormProps {
  onSubmit?: (formData: ReportFormData) => void;
}

export interface ReportFormData {
  type: string;
  description: string;
  location: string;
  time: string;
  anonymous: boolean;
}

const ReportForm: React.FC<ReportFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<ReportFormData>({
    type: '',
    description: '',
    location: '',
    time: '',
    anonymous: false,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: checked,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSubmit) {
      onSubmit(formData);
    } else {
      console.log('Form submitted:', formData);
      alert('Report submitted successfully! Thank you for helping make our community safer.');
      // Reset form
      setFormData({
        type: '',
        description: '',
        location: '',
        time: '',
        anonymous: false,
      });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <AlertTriangle className="text-orange-500 w-6 h-6 mr-2" />
        <h2 className="text-xl font-semibold">Report Unsafe Area</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">
            Incident Type
          </label>
          <select
            id="type"
            name="type"
            value={formData.type}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          >
            <option value="" disabled>Select incident type</option>
            <option value="harassment">Harassment</option>
            <option value="assault">Assault or Threat</option>
            <option value="poorLighting">Poor Lighting</option>
            <option value="suspiciousActivity">Suspicious Activity</option>
            <option value="unsafeInfrastructure">Unsafe Infrastructure</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={3}
            required
            placeholder="Please provide details about the incident or unsafe conditions"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
              Location
            </label>
            <div className="relative">
              <input
                id="location"
                name="location"
                type="text"
                value={formData.location}
                onChange={handleChange}
                required
                placeholder="Enter address or location name"
                className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            </div>
            <button 
              type="button" 
              className="mt-1 text-xs text-purple-600 hover:text-purple-800"
            >
              Use current location
            </button>
          </div>

          <div>
            <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-1">
              Time of Incident
            </label>
            <input
              id="time"
              name="time"
              type="datetime-local"
              value={formData.time}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-4 pt-2">
          <Button 
            type="button" 
            variant="outline" 
            size="sm"
            icon={<Camera className="h-4 w-4" />}
          >
            Add Photo
          </Button>
          <div className="text-sm text-gray-500">No file selected</div>
        </div>

        <div className="flex items-center">
          <input
            id="anonymous"
            name="anonymous"
            type="checkbox"
            checked={formData.anonymous}
            onChange={handleCheckboxChange}
            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
          />
          <label htmlFor="anonymous" className="ml-2 block text-sm text-gray-700">
            Submit anonymously
          </label>
        </div>

        <div className="pt-4">
          <Button 
            type="submit" 
            variant="primary" 
            fullWidth
            icon={<Send className="h-4 w-4" />}
          >
            Submit Report
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ReportForm;