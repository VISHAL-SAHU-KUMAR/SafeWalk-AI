import React from 'react';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import Router from './components/router/Router';
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import MapPage from './pages/MapPage';
import ReportPage from './pages/ReportPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';

function App() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Router
          routes={[
            { path: '/', element: <HomePage /> },
            { path: '/login', element: <LoginPage /> },
            { path: '/signup', element: <SignupPage /> },
            { path: '/map', element: <MapPage /> },
            { path: '/report', element: <ReportPage /> },
            { path: '/about', element: <AboutPage /> },
            { path: '/contact', element: <ContactPage /> },
          ]}
        />
      </main>
      <Footer />
    </div>
  );
}

export default App;